/**
    \file main3D.cpp
    Main program to test 3D distance transform algorithms.

    \author George J. Grevera, Ph.D., ggrevera@sju.edu

    Copyright (C) 2002, George J. Grevera

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for mor
    e details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
    USA or from http://www.gnu.org/licenses/gpl.txt.

    This General Public License does not permit incorporating this
    code into proprietary programs.  (So a hypothetical company such
    as GH (Generally Hectic) should NOT incorporate this code into
    their proprietary programs.)
 */

static const int  size         = 50;  ///< 3D images of size x size x size
static const int  slices       = 20;
static const int  iterCount    =  1;
static const int  borderOffset =  2;

typedef    unsigned char    uchar;

//#define CenterPointTest
#define  PointTest

#ifdef  PointTest
  #if 0
    //the original "dreaded" test
    static const int ptCount  = 3;
    static const int ptOffset = size/2;
    static int pt[ptCount][3] = { { 0+ptOffset, 2+ptOffset },    // x,y
                                  { 1+ptOffset, 6+ptOffset },
                                  { 2+ptOffset, 8+ptOffset } };
  #endif
  #if 0
    //a reflection of the original "dreaded" test
    static const int ptCount  = 3;
    static const int ptOffset = size/2;
    static int pt[ptCount][3] = { { ptOffset-0, 2+ptOffset },    // x,y
                                  { ptOffset-1, 6+ptOffset },
                                  { ptOffset-2, 8+ptOffset } };
  #endif
  #if 0
    //one point in the center
    static const int ptCount  = 1;
    static int       pt[ptCount][3] = { { size/2, size/2, size/2 } };  // x,y,z
  #endif
  #if 1
    #define RandomTest
    static const int ptCount = (int)(0.80*size*size*slices);
    static int       pt[ptCount][3];  //will be randomly filled in
  #endif
#endif

#include <assert.h>
#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <typeinfo>

#include "DistanceTransform2D.h"
#include "DistanceTransform3D.h"
#include "Simple3D.h"
#include "SimpleList3D.h"

#ifdef WIN32
#  include <windows.h>
#  include <winbase.h>
#endif

#include "Timer.h"
#include "TIFFWriter.h"

using namespace std;
//----------------------------------------------------------------------
/// Normal class which samples random numbers from a normal distribution using the Box-Muller transform.
class Normal {
private:
    bool    mValid;  ///< has the second random number been cached?
    double  mX2;     ///< this method generates pairs of random numbers, caching the second one here.

    /// this method returns a random number in the range [0.0 ... 1.0].
    double Random ( ) {
        const double  r = rand();
        return r / RAND_MAX;
    }

public:
    /// class constructor.
    Normal ( ) {
        mValid = false;
        mX2    = 0;
        srand( time(NULL) );
    }

    /// given a mean m and std dev s, return a sample from a normal distribution.
    double sample ( double m=0.0, double s=1.0 ) {
        // normal distribution with mean m and standard deviation s
        if (mValid) {     // we have a valid result from last call
            mValid = false;
            return mX2 * s + m;
        }
    
        // make two normally distributed variates by Box-Muller transformation
        double  x1;  // first random coordinate (second one is class member)
        double  w;   // radius
        do {
            x1  = 2.0 * Random() - 1.0;  // -1..1
            mX2 = 2.0 * Random() - 1.0;  // -1..1
            w = x1*x1 + mX2*mX2;
        } while (w >= 1.0 || w < 1E-30);
        w = sqrt(log(w)*(-2.0/w));
        x1     *= w;
        mX2    *= w;     // x1 and x2 are independent, normally distributed variables
        mValid =  true;  // cache x2 for next call
        return x1 * s + m;
    }
};
//----------------------------------------------------------------------
static void writeDistance ( const char* const fname, DistanceTransform3D* dt )
{
    // cout << endl << "writeDistance: skip writing distance." << endl;  return;
    double*  d = (double*)malloc( ::size * ::size * ::slices * sizeof(double) );
    assert(d!=NULL);
    int  i=0, z;
    double  max = dt->getD(0,0,0);
    for (z=0; z< ::slices; z++) {
        for (int y=0; y< ::size; y++) {
            for (int x=0; x< ::size; x++) {
                double  v = dt->getD(x,y,z);
                if (v<0)    v = -v;
                if (v >= DistanceTransform2D::IntInfinity
                 || v >= DistanceTransform2D::FloatInfinity) {
                    v = 0;
                }
                d[i] = v;
                if (d[i]>max)    max=d[i];
                ++i;
            }
        }
    }
    for (z=0; z< ::slices; z++) {
        char  buff[256];
        sprintf( buff, "%03d-%s", z, fname );
        TIFFWriter::write_tiff_double_grey( &d[z*size*size], size, size,
            buff, max );
    }
    free(d);   d=NULL;
}
//----------------------------------------------------------------------
static void writeBinaryImage ( const char* const fname, const uchar* const I )
{
    //write the entire 3d data set to a single, binary file
    {
        FILE*  fp = fopen( "input.uchar", "wb" );
        assert( fp!=NULL );
        int  n = fwrite( I, sizeof *I, ::size*::size*::slices, fp );
        assert( n == (::size*::size*::slices ) );
        fclose( fp );    fp=NULL;
    }
    
    //save a tiff image of the original binary image data
    uchar*  uc = (uchar*)malloc( ::size * ::size * ::slices * sizeof(uchar) );
    assert( uc!=NULL );
    for (int i=0; i< ::size*::size*::slices; i++) {
        if (I[i])    uc[i]=255;
        else         uc[i]=  0;
    }
    for (int z=0; z< ::slices; z++) {
        char  buff[256];
        sprintf( buff, "%03d-original.tif", z );
        FILE*  fp = fopen( buff, "wb" );
        assert( fp!=NULL );
        TIFFWriter::write_tiff_data8_grey( &uc[z*size*size], ::size, ::size,
                                           fp, 1 );
        fclose( fp );    fp=NULL;
    }
    free( uc );      uc=NULL;
}
//----------------------------------------------------------------------
static void getMinMax ( DistanceTransform3D* dt ) {
    double  min =  DistanceTransform2D::FloatInfinity;
    double  max = -DistanceTransform2D::FloatInfinity;
    for (int z=::borderOffset; z<slices-::borderOffset; z++) {
        for (int y=::borderOffset; y<size-::borderOffset; y++) {
            for (int x=::borderOffset; x<size-::borderOffset; x++) {
                const double d = dt->getD(x,y,z);
                if (d >=  DistanceTransform2D::IntInfinity || d >=  DistanceTransform2D::FloatInfinity)  continue;
                if (d <= -DistanceTransform2D::IntInfinity || d <= -DistanceTransform2D::FloatInfinity)  continue;
                if (d>max)  max=d;
                if (d<min)  min=d;
            }
        }
    }
    cout << "    min=" << min << ", max=" << max
         << " (not including borders)" << endl;
}
//----------------------------------------------------------------------
static uchar getData ( const uchar* const I, const int x, const int y, const int z ) {
    if (x<0 || y<0 || x>=size || y>=size || z<0 || z>=slices)    return 0;
    return I[z*size*size + y*size + x];
}
//----------------------------------------------------------------------
static inline bool isBorderElement ( const uchar* const I, const int x,
                                     const int y, const int z )
{
    const uchar  center = getData(I, x, y, z);
    uchar  other;

    other = getData(I, x-1, y, z);
    if (center != other)  return true;
    other = getData(I, x+1, y, z);
    if (center != other)  return true;
    other = getData(I, x, y-1, z);
    if (center != other)  return true;
    other = getData(I, x, y+1, z);
    if (center != other)  return true;
    other = getData(I, x, y, z-1);
    if (center != other)  return true;
    other = getData(I, x, y, z+1);
    if (center != other)  return true;
    return false;
}
//----------------------------------------------------------------------
static void checkError ( const uchar* const I,
                         const DistanceTransform3D* const dt,
                         const char* const diffFileName,
                         const DistanceTransform3D* const gold ) {
#ifdef PointTest
    double*  diffImage = (double*)malloc( size*size*slices*sizeof(double) );
    assert( diffImage!=NULL );
    for (int i=0; i<size*size*slices; i++)    diffImage[i]=0;

    double  maxDiff   = 0;
    int     maxDiffX  =-1;
    int     maxDiffY  =-1;
    int     maxDiffZ  =-1;
    double  err       = 0;
    long    count     = 0;
    long    diffCount = 0;

    int  z;
    for (z=::borderOffset; z<slices-::borderOffset; z++) {
        for (int y=::borderOffset; y<size-::borderOffset; y++) {
            for (int x=::borderOffset; x<size-::borderOffset; x++) {
                const double  d  = dt->getD(x,y,z);
                const double  gd = gold->getD(x,y,z);
                if (d==DistanceTransform2D::IntInfinity || d==DistanceTransform2D::FloatInfinity) {
                    cout << "checkError: infinite distance at ("
                        << x << "," << y << ") ignored." << endl;
                    continue;
                }
                
                ++count;
                double  magDiff = fabs(d - gd);
                diffImage[z*size*size + y*size + x] = magDiff;
                if (magDiff > 0) {
                    ++diffCount;
                    err += (d-gd)*(d-gd);
                    if (magDiff > maxDiff) {
                        maxDiff  = magDiff;
                        maxDiffX = x;
                        maxDiffY = y;
                        maxDiffZ = z;
                    }
                }
                
            }
        }
    }

    err /= count;
    err =  sqrt(err);
    cout << ", rmse=" << err << ", max diff=" << maxDiff
         << " at (" << maxDiffX << "," << maxDiffY << "," << maxDiffZ << "), diff count="
         << diffCount
         << endl;

    for (z=0; z<slices; z++) {
        char  buff[256];
        sprintf( buff, "%03d-%s", z, diffFileName );
        TIFFWriter::write_tiff_double_grey( &diffImage[z*size*size], size, size, buff );
    }
    free(diffImage);    diffImage=NULL;
#endif
}
//----------------------------------------------------------------------
static void checkError ( const uchar* const I,
                         const DistanceTransform3D* const dt,
                         const char* const diffFileName ) {
#ifdef PointTest
    double*  diffImage = (double*)malloc( size*size*slices*sizeof(double) );
    assert( diffImage!=NULL );
    for (int i=0; i<size*size*slices; i++)    diffImage[i]=0;

    double maxDiff   = 0;
    int    maxDiffX  =-1;
    int    maxDiffY  =-1;
    int    maxDiffZ  =-1;
    double err       = 0;
    long   count     = 0;
    long   diffCount = 0;

    int  z;
    for (z=::borderOffset; z<slices-::borderOffset; z++) {
        for (int y=::borderOffset; y<size-::borderOffset; y++) {
            for (int x=::borderOffset; x<size-::borderOffset; x++) {
                //is the point an element of the border?
                if (isBorderElement(I, x, y, z)) {
                    //yes, so its distance should be 0
                    const double d = fabs( dt->getD(x,y,z) );
                    if (d==DistanceTransform2D::IntInfinity || d==DistanceTransform2D::FloatInfinity) {
                        // cout << "checkError: "
                        //      << "infinite distance for border element at ("
                        //      << x << "," << y << ")" << endl;
                        continue;
                    }
                    if (d!=0.0) {
                        cout << "checkError: non zero distance=" << d
                            << " for border element at "
                            << "(" << x << "," << y << ")"
                            << endl;
                        ++diffCount;
                    }
                    diffImage[z*size*size + y*size + x] = d;
                    err += d*d;
                    ++count;
                } else {
                    const double d = fabs( dt->getD(x,y,z) );
                    if (d==DistanceTransform2D::IntInfinity || d==DistanceTransform2D::FloatInfinity) {
                        // cout << "checkError: "
                        //      << "infinite distance for non border element at ("
                        //      << x << "," << y << ")" << endl;
                        continue;
                    }
                    ++count;
                    //calc min distance from this point to points on the 
                    // border points in the list
                    double  min = DistanceTransform2D::FloatInfinity;
                    for (int r=0; r< ::ptCount; r++) {
                        int  iex, iey, iez;
                        
                        iex = ::pt[r][0]-1,    iey = ::pt[r][1],    iez = ::pt[r][2];
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }
                        
                        iex = ::pt[r][0]+1,    iey = ::pt[r][1],    iez = ::pt[r][2];
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }
                        
                        iex = pt[r][0],    iey = pt[r][1]-1,    iez = ::pt[r][2];
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }
                        
                        iex = pt[r][0],    iey = pt[r][1]+1,    iez = ::pt[r][2];
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }

                        iex = pt[r][0],    iey = pt[r][1],    iez = ::pt[r][2]-1;
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }

                        iex = pt[r][0],    iey = pt[r][1],    iez = ::pt[r][2]+1;
                        if (isBorderElement(I, iex, iey, iez)) {
                            const double tmp = sqrt( (double)( (x-iex)*(x-iex) +
                                (y-iey)*(y-iey) + (z-iez)*(z-iez) ) );
                            if (tmp<min)  min=tmp;
                        }
                    }
                    double tmpDiff = (d-min)*(d-min);
                    err += tmpDiff;
                    tmpDiff = sqrt(tmpDiff);
                    if (tmpDiff>maxDiff) {
                        maxDiff  = tmpDiff;
                        maxDiffX = x;
                        maxDiffY = y;
                        maxDiffZ = z;
                    }
                    
                    diffImage[z*size*size + y*size + x] = fabs(d - min);
                    // diffImage[y*size + x] = (!(d == min));
                    // diffImage[y*size + x] = (!(d == min));
                    if (!(d==min)) {
                        ++diffCount;
                        //int px, py;
                        // if ( dt->getP(x, y, px, py) )
                        //     cout << "    p(" << x << "," << y << ")=(" << px
                        //     << "," << py << ")" << endl;
                    }
                }
                
            }
        }
    }

    err /= count;
    err =  sqrt(err);
    cout << ", rmse=" << err << ", max diff=" << maxDiff
         << " at (" << maxDiffX << "," << maxDiffY << "," << maxDiffZ << "), diff count="
         << diffCount
         << endl;

    for (z=0; z<slices; z++) {
        char  buff[256];
        sprintf( buff, "%03d-%s", z, diffFileName );
        TIFFWriter::write_tiff_double_grey( diffImage, size, size, buff );
    }
    free(diffImage);    diffImage=NULL;
#endif
}
//----------------------------------------------------------------------
static void checkCenterPointError ( DistanceTransform3D* dt ) {
  #ifdef CenterPointTest
    const int c=size/2;

    assert( dt->getD(c, c, c) == 0 );

    assert( dt->getD(c-1, c,   c)   == 0 );
    assert( dt->getD(c+1, c,   c)   == 0 );
    assert( dt->getD(c,   c-1, c)   == 0 );
    assert( dt->getD(c,   c+1, c)   == 0 );
    assert( dt->getD(c,   c,   c-1) == 0 );
    assert( dt->getD(c,   c,   c+1) == 0 );

    double err2=0, maxErr=0;
    int    maxX=-1, maxY=-1, maxZ=-1;
    int    count=0;
    double A=0, B=0;  //to calc variance
    //const int off  = 10;
    for (int z=::borderOffset; z<slices-::borderOffset; z++) {
        for (int y=::borderOffset; y<size-::borderOffset; y++) {
            for (int x=::borderOffset; x<size-::borderOffset; x++) {
                if (z==c && y==c && x==c)  continue;
                const double d = fabs( dt->getD(x,y,z) );
                if (d==DistanceTransform2D::IntInfinity || d==DistanceTransform2D::FloatInfinity)  continue;
                
                ++count;
                //calc min distance from this point to points on the 
                // immediate exterior (which also have 0 assigned to them)
                int    iex=c-1, iey=c, iez=c;
                double min = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                
                iex=c+1,  iey=c,  iez=c;
                double tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                if (tmp<min)  min=tmp;
                
                iex=c,  iey=c-1,  iez=c;
                tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                if (tmp<min)  min=tmp;
                
                iex=c,  iey=c+1,  iez=c;
                tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                if (tmp<min)  min=tmp;
                
                iex=c,  iey=c,  iez=c-1;
                tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                if (tmp<min)  min=tmp;
                
                iex=c,  iey=c,  iez=c+1;
                tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) + (z-iez)*(z-iez) );
                if (tmp<min)  min=tmp;
                
                A += (d-min)*(d-min);
                B += (d-min);
                const double e2=(d-min)*(d-min);
                err2 += e2;
                if (e2>maxErr) {
                    maxErr = e2;
                    maxX   = x;
                    maxY   = y;
                    maxZ   = z;
                }
            }
        }
    }
    cout << "checkCenterPointError: total ie error^2=" << err2
         << ", mse=" << err2/count << " (rmse=" << sqrt(err2/count) << ")";
    const double var = (A - B*B/count)/(count-1);
    cout << ", total ie variance=" << var << ", max err=" << sqrt(maxErr)
         << " @ (" << maxX << "," << maxY << "," << maxZ << ")";
    if (maxX!=-1 && maxY!=-1 && maxZ!=-1)    cout << "=" << dt->getD(maxX,maxY,maxZ);
    cout << endl << endl;
#if 0
    for (y=0; y<size; y++) {
        for (int x=0; x<size; x++) {
            if (y==c && x==c)  continue;  //skip the center
            const double d = fabs( dt->getD(x,y) );
            if (d==DistanceTransform2D::IntInfinity || d==DistanceTransform2D::FloatInfinity)  continue;
            //calc min distance from this point to points on the 
            // immediate exterior (which also have 0  assigned to them)
            int    iex=c-1, iey=c;
            double min = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) );

            iex=c+1,  iey=c;
            double tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) );
            if (tmp<min)  min=tmp;

            iex=c,  iey=c-1;
            tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) );
            if (tmp<min)  min=tmp;

            iex=c,  iey=c+1;
            tmp = sqrt( (x-iex)*(x-iex) + (y-iey)*(y-iey) );
            if (tmp<min)  min=tmp;

            const double e2=fabs(d-min);
            if (e2>=maxErr) {
                cout << "max ie err        =" << maxErr << " @ (" << x
                     << "," << y << ")" << endl;
            }
        }
    }
#endif
  #endif
}
//----------------------------------------------------------------------
#if 0
static void colorParent ( const DistanceTransform3D* const dt,
                          const char* const binFileName,
                          const int px, const int py )
{
    #ifndef PointTest
        return;
    #endif

    double* binImage = (double*)malloc(size*size*slices*sizeof(double));
    assert(binImage!=NULL);
    for (int i=0; i<size*size*slices; i++)    binImage[i]=0;
#ifdef WIN32
    if (true) {
#else
    //doesn't work when using the Windows NiceTry compiler
    if (typeid(*dt) == typeid(DijkstraVectors) ) {
#endif
        const DijkstraVectors* const dv = (const DijkstraVectors* const)dt;
        for (int y=::borderOffset; y<size-::borderOffset; y++) {
            for (int x=::borderOffset; x<size-::borderOffset; x++) {
                int i=0, tx=-1, ty=-1;
                bool foundIt=false;
                while ( dv->getP(x, y, tx, ty, i) ) {
                    if (tx == px && ty == py) {
                        foundIt=true;
                        break;
                    }  //fi
                    i++;
                }  //elihw
                if (foundIt)    binImage[y*size + x] = 1;
            }  //rof x
        }  //for y

        cout << endl << endl << endl;
        int tx, ty;
        dv->getP(26, 31, tx, ty);
        dv->getD(26, 31);
    }  //fi

    TIFFWriter::write_tiff_double_grey( binImage, size, size, binFileName );
    free(binImage);    binImage=NULL;
}
#endif
//----------------------------------------------------------------------
//int main3D ( const int argc, const char* const argv[] ) {
void main3D ( void ) {

    uchar*  I = (uchar*)malloc( size*size*slices*sizeof(*I) );
    assert( I!=NULL );
    int  i;
    for (i=0; i<size*size*slices; i++)  I[i]=0;

    cout << endl << "iteration count = " << ::iterCount << endl;

#ifdef RandomTest
    cout << "random test.  input image size: (" << ::size << "," << ::size
         << "," << ::slices
         << "), " << ::ptCount << " random points. "
         << 100.0*((double)::ptCount/(::size * ::size * ::slices)) << "%."
         << endl;
    const int  tSeed = 5;  //time(NULL);
    srand( tSeed );
    cout << "random number generator seeded w/ time: " << tSeed << "." << endl;
    // srand( 10 );    cout << "constant random number seed." << endl;
    Normal  norm;
    for (int k=0; k< ::ptCount; k++) {

        int  r1, r2, r3;
        //sample from a uniform distribution
        //r1 = (rand() % (::size - ::borderOffset)) + 5;
        //r2 = (rand() % (::size - ::borderOffset)) + 5;

        //sample from a normal distribution (stddev typically 0.05 or 0.2)
        r1 = (int)norm.sample( ::size/2,   ::size*0.1 );    //x
        r2 = (int)norm.sample( ::size/2,   ::size*0.1 );    //y
        r3 = (int)norm.sample( ::slices/2, ::slices*0.1 );  //z

        if (r1 <  ::borderOffset)           r1 = ::borderOffset;
        if (r1 >= ::size-::borderOffset)    r1 = ::size-::borderOffset;
        if (r2 <  ::borderOffset)           r2 = ::borderOffset;
        if (r2 >= ::size-::borderOffset)    r2 = ::size-::borderOffset;
        if (r3 <  ::borderOffset)           r3 = ::borderOffset;
        if (r3 >= ::slices-::borderOffset)  r3 = ::slices-::borderOffset;
        ::pt[k][0] = r1;  //x
        ::pt[k][1] = r2;  //y
        ::pt[k][2] = r3;  //z
        I[r3*size*size + r2*size + r1] = 1;
    }
#endif

#ifdef CenterPointTest
    I[slices/2*size*size + size/2*size + size/2] = 1;  //single point in center
    cout << "center at (" << size/2 << "," << size/2 << ")="
         << (int)I[size/2*size + size/2] << endl;
#endif

#ifdef PointTest
    cout << "point test.  input image size: (" << ::size << "," << ::size << ","
         << ::size << ")" << endl;
    for (int r=0; r<ptCount; r++) {
        const int  x = ::pt[r][0];
        const int  y = ::pt[r][1];
        const int  z = ::pt[r][2];
        I[z*size*size + y*size + x] = 1;
    }
#endif

#if !defined(CenterPointTest) && !defined(PointTest)
    I[size/3*size + size/3]   = 1;
    I[size/2*size + 3*size/4] = 1;
    I[3*size/4*size + size/4] = 1;
#endif

    writeBinaryImage( "original.tif", I );
    cout << "gold standard (SimpleList3D)" << endl;
    Timer* t = new Timer("SimpleList3D");
        SimpleList3D*  gold = new SimpleList3D(size, size, slices);
        gold->doTransform( I );
    delete t;  t=NULL;
    gold->saveResult( "output.double" );

    if (true) {
        cout << "Simple3D running" << endl;
        Timer* t = new Timer("Simple3D");
            Simple3D* dt = new Simple3D(size, size, slices);
            for (i=1; i<=iterCount; i++)    dt->doTransform(I);
        delete t;  t=NULL;
        getMinMax(dt);
        writeDistance("Simple3D.tif", dt);
#ifdef CenterPointTest
        checkCenterPointError(dt);
#endif
        checkError(I, dt, "Simple3D_diff.tif", gold);
    } else {
        cout << "Simple3D not running" << endl;
    }

    if (true) {
        cout << "SimpleList3D running" << endl;
        Timer* t = new Timer("SimpleList3D");
            SimpleList3D* dt = new SimpleList3D(size, size, slices);
            for (i=1; i<=iterCount; i++)    dt->doTransform(I);
        delete t;  t=NULL;
        getMinMax(dt);
        writeDistance("SimpleList3D.tif", dt);
#ifdef CenterPointTest
        checkCenterPointError(dt);
#endif
        checkError(I, dt, "SimpleList3D_diff.tif", gold);
    }
}
//----------------------------------------------------------------------

