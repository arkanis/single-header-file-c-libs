/**
    \file SimpleList.h
    Header file for SimpleList 2D distance transform class which, given
    an input binary image, calculates the corresponding distance transform.

    \author George J. Grevera, Ph.D., ggrevera@sju.edu

    Copyright (C) 2002, George J. Grevera

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
    USA or from http://www.gnu.org/licenses/gpl.txt.

    This General Public License does not permit incorporating this
    code into proprietary programs.  (So a hypothetical company such
    as GH (Generally Hectic) should NOT incorporate this code into
    their proprietary programs.)
 */
#ifndef SimpleList_h
#define SimpleList_h

#include "DistanceTransform2D.h"
#include <iostream>
using namespace std;
//----------------------------------------------------------------------
/** \brief SimpleList 2D distance transform algorithm.
 *
 *  The SimpleList distance transform is simply an exhaustive search but
 *  it employs a list of border points.  It compares each non border point
 *  to its distance from each border point and determines the minimum 
 *  distance (from the non border point to the border points).
 */
class SimpleList : public DistanceTransform2D {

public:
    SimpleList ( const int xSize, const int ySize, const bool unload=true )
        : DistanceTransform2D(xSize, ySize, unload)
    {
    }

    void doTransform ( const unsigned char* const I );

    /**
     * @param x is the x location
     * @param y is the y location
     * @param px is the parent's x location to be returned
     * @param py is the parent's y location to be returned
     * @return true if the parent is know; otherwise false.
     */
    virtual inline bool getP ( const int x, const int y, int& px, int& py ) const {
        if (p==NULL)    return false;
        const int s = sub(x,y);
        px = p[s].x;
        py = p[s].y;
        return true;
    }

protected:
    P *p;
};

#endif
//----------------------------------------------------------------------
