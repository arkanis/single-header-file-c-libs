/**
    \file Chamfer_5x5.h
    Header file for Chamfer_5x5 distance transform class which, given an
    input binary image, calculates the corresponding distance transform.

    \author George J. Grevera, Ph.D., ggrevera@sju.edu

    Copyright (C) 2002, George J. Grevera

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
    USA or from http://www.gnu.org/licenses/gpl.txt.

    This General Public License does not permit incorporating this
    code into proprietary programs.  (So a hypothetical company such
    as GH (Generally Hectic) should NOT incorporate this code into
    their proprietary programs.)
 */
#ifndef Chamfer_5x5_h
#define Chamfer_5x5_h

#include "DistanceTransform2D.h"
//----------------------------------------------------------------------
/// Borgefors' Chamfer distance using a 5x5 window
class Chamfer_5x5 : public DistanceTransform2D {

public:
    Chamfer_5x5 ( const int xSize, const int ySize, const bool unload=true )
        : DistanceTransform2D(xSize, ySize, unload)
    {
    }

    /**
        this method simply calls the other doTransform method with the
        following arguments: doTransform(I, 5, 7, 11, true).
     */
    void doTransform ( const unsigned char* const I ) {
        doTransform(I, 5, 7, 11, true);
    }

    void doTransform ( const unsigned char* const I, const int a,
                       const int b, const int c,
                       const bool halfIsZero );

private:
    void borderCheck ( const unsigned char* const I );

};

#endif
//----------------------------------------------------------------------

